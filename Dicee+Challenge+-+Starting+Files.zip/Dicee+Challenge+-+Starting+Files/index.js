var randomVariable1 = Math.floor(Math.random() * 6) + 1;
var randomVariable2 = Math.floor(Math.random() * 6) + 1;

var no1 = "images/dice" + randomVariable1 + ".png";
var no2 = "images/dice" + randomVariable2 + ".png";

document.querySelector(".img1").setAttribute("src", no1);
document.querySelector(".img2").setAttribute("src", no2);

if(randomVariable1>randomVariable2){
    document.querySelector(".container>h1").textContent="Player 1 Wins!";
}else if(randomVariable1<randomVariable2){
    document.querySelector(".container>h1").textContent="Player 2 Wins!";
}else{
    document.querySelector(".container>h1").textContent="Draw!";
}