var userclicked=[];
var gamepattern=[];
var buttoncolors=["red", "blue", "green", "yellow"];
function newsequence(){   
    var num=Math.floor((Math.random()*4));
    var randomchosencolour=buttoncolors[num];
    gamepattern.push(randomchosencolour);
    $("#"+randomchosencolour).animate({opacity: 0.5}, 100).animate({opacity: 1}, 100);
    makesound(randomchosencolour);
    animatepress(randomchosencolour);
}
var n=1
function checkbtn(){
    for(var i=0;i<userclicked.length;i++){
        if(userclicked[i]!==gamepattern[i]){
            gamepattern.length = 0;
            userclicked.length = 0;
            $("#level-title").text("Press A Key to start");
            n=0;
            $("body").addClass("game-over");
            setTimeout(function(){
                $("body").removeClass("game-over");
                var ad = new Audio("./sounds/wrong.mp3");
                ad.play();
            },200);
            
            return;
        }
    }if(userclicked.length===gamepattern.length){
        setTimeout(function(){
            newsequence();
            n++;
            $("#level-title").text("Level " + n);
            userclicked.length=0;
        },500);
    }
}
$("body").on("keypress",function() {
    if (gamepattern.length === 0) {
        $("#level-title").text("Level 1");
        newsequence();
         
    }
});


$(".btn").on("click", function() {
    var userChosenColor = $(this).attr("id");
    userclicked.push(userChosenColor);
    makesound(userChosenColor);
    animatepress(userChosenColor);
    checkbtn(); 
});

function makesound(name){
    var audio = new Audio("./sounds/" + name + ".mp3");
    audio.play();
}
function animatepress(currentcolor){
    $("#"+currentcolor).addClass("pressed");
    setTimeout(function(){
        $("#"+currentcolor).removeClass("pressed");
    },100);
}